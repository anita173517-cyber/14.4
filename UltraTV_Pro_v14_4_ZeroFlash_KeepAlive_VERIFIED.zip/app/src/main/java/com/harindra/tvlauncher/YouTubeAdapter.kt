package com.harindra.tvlauncher

import android.view.LayoutInflater
import android.view.View
import android.graphics.Outline
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class YouTubeAdapter(
    private val prefs: PrefsManager,
    private val onVideoClick: (YouTubeVideo) -> Unit,
    private val onItemFocused: ((String, Int) -> Unit)? = null
) : ListAdapter<YouTubeVideo, YouTubeAdapter.YtViewHolder>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<YouTubeVideo>() {
            override fun areItemsTheSame(a: YouTubeVideo, b: YouTubeVideo) = a.videoId == b.videoId
            override fun areContentsTheSame(a: YouTubeVideo, b: YouTubeVideo) = a == b
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): YtViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_youtube_card, parent, false)
        return YtViewHolder(view)
    }

    override fun onBindViewHolder(holder: YtViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    override fun onViewRecycled(holder: YtViewHolder) {
        super.onViewRecycled(holder)
        MediaImageLoader.cancelRequest(holder.ivThumb)
    }

    inner class YtViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivThumb: ImageView = itemView.findViewById<ImageView>(R.id.ivYtThumb).apply {
            val r = 18f * resources.displayMetrics.density
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, r)
                }
            }
            clipToOutline = true
        }
        private val tvTitle: TextView = itemView.findViewById(R.id.tvYtTitle)
        private val tvChannel: TextView = itemView.findViewById(R.id.tvYtChannel)
        private val tvDuration: TextView = itemView.findViewById(R.id.tvYtDuration)

        fun bind(video: YouTubeVideo) {
            tvTitle.text = video.title
            tvChannel.text = video.channelName
            tvDuration.text = video.badge
            MediaImageLoader.loadRemoteImage(video.thumbUrl, ivThumb, video.fallbackResId, 440)

            itemView.setOnClickListener { onVideoClick(video) }
            itemView.setOnFocusChangeListener { v, hasFocus ->
                val tier = PerformanceTier.resolve(v.context, prefs)
                Animation4D.applyTierFocus(v, hasFocus, tier, prefs.enable4dAnimations)
                if (hasFocus && tier.enableDynamicBackdrop) onItemFocused?.invoke(video.thumbUrl, video.fallbackResId)
            }
        }
    }
}
