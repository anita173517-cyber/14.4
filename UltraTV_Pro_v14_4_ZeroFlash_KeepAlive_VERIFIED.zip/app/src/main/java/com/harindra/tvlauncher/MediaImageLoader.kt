package com.harindra.tvlauncher

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.Future

object MediaImageLoader {

    private const val MAX_IMAGE_BYTES = 4 * 1024 * 1024 // 4 MB strict OOM safety limit
    private var maxCacheKb = 8192
    private var cache: LruCache<String, Bitmap> = createCache(maxCacheKb)

    private val appExecutor = Executors.newFixedThreadPool(2)
    private val netExecutor = Executors.newFixedThreadPool(3)
    private val activeTasks = ConcurrentHashMap<Int, Future<*>>()
    private val mainHandler = Handler(Looper.getMainLooper())

    fun initForTier(tier: PerformanceTier) {
        if (maxCacheKb != tier.cacheKb) {
            maxCacheKb = tier.cacheKb
            cache.evictAll()
            cache = createCache(maxCacheKb)
        }
    }

    fun initForDevice(context: Context) {
        val tier = PerformanceTier.resolve(context, PrefsManager(context))
        initForTier(tier)
    }

    private fun createCache(sizeKb: Int): LruCache<String, Bitmap> {
        return object : LruCache<String, Bitmap>(sizeKb) {
            override fun sizeOf(key: String, value: Bitmap): Int =
                (value.byteCount / 1024).coerceAtLeast(1)
        }
    }

    fun cancelRequest(target: ImageView) {
        val id = System.identityHashCode(target)
        activeTasks.remove(id)?.cancel(true)
        target.tag = null
    }

    fun loadAppIcon(pm: PackageManager, packageName: String, target: ImageView) {
        val id = System.identityHashCode(target)
        activeTasks.remove(id)?.cancel(true)

        val key = "pkg:$packageName"
        target.tag = key
        val cached = cache.get(key)
        if (cached != null && !cached.isRecycled) {
            target.setImageBitmap(cached)
            return
        }

        target.setImageResource(
            when {
                packageName == "com.harindra.iptvpro" -> R.drawable.ic_3d_iptv
                packageName == MovieBoxEngine.MOVIEBOX_TV_PKG -> R.drawable.ic_3d_moviebox
                else -> R.drawable.ic_3d_apps
            }
        )

        val future = appExecutor.submit {
            val bmp = try {
                val drawable = pm.getApplicationBanner(packageName)
                    ?: pm.getApplicationIcon(packageName)
                drawableToScaledBitmap(drawable, 112)
            } catch (_: Throwable) { null }

            if (bmp != null && !Thread.currentThread().isInterrupted) {
                cache.put(key, bmp)
                mainHandler.post {
                    if (target.tag == key && !bmp.isRecycled) {
                        target.setImageBitmap(bmp)
                    }
                }
            }
            activeTasks.remove(id)
        }
        activeTasks[id] = future
    }


    fun loadLocalBackdropRes(resId: Int, target: ImageView, tier: PerformanceTier) {
        val id = System.identityHashCode(target)
        activeTasks.remove(id)?.cancel(true)

        val maxW = if (tier.id >= PerformanceTier.CINEMATIC.id) 960 else 640
        val key = "res:${resId}_$maxW"
        target.tag = key
        val cached = cache.get(key)
        if (cached != null && !cached.isRecycled) {
            target.setImageBitmap(cached)
            return
        }

        val res = target.resources
        val future = appExecutor.submit {
            val bmp = try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeResource(res, resId, bounds)
                var sample = 1
                while (bounds.outWidth / sample > maxW) sample *= 2
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                BitmapFactory.decodeResource(res, resId, opts)
            } catch (_: Throwable) { null }

            if (bmp != null && !Thread.currentThread().isInterrupted) {
                cache.put(key, bmp)
                mainHandler.post {
                    if (target.tag == key && !bmp.isRecycled) {
                        target.setImageBitmap(bmp)
                    }
                }
            }
            activeTasks.remove(id)
        }
        activeTasks[id] = future
    }

    fun loadRemoteImage(url: String, target: ImageView, fallbackResId: Int, targetWidthPx: Int = 440) {
        val id = System.identityHashCode(target)
        activeTasks.remove(id)?.cancel(true)

        if (url.isBlank() || (!url.startsWith("http://") && !url.startsWith("https://"))) {
            target.tag = null
            target.setImageResource(fallbackResId)
            return
        }

        val key = "img:$url"
        target.tag = key
        val cached = cache.get(key)
        if (cached != null && !cached.isRecycled) {
            target.setImageBitmap(cached)
            return
        }

        target.setImageResource(fallbackResId)

        val future = netExecutor.submit {
            val bmp = fetchBitmapSafe(url, targetWidthPx)
            if (bmp != null && !Thread.currentThread().isInterrupted) {
                cache.put(key, bmp)
                mainHandler.post {
                    if (target.tag == key && !bmp.isRecycled) {
                        target.setImageBitmap(bmp)
                    }
                }
            }
            activeTasks.remove(id)
        }
        activeTasks[id] = future
    }

    private fun fetchBitmapSafe(url: String, maxDim: Int): Bitmap? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 4500
                readTimeout = 6000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Mozilla/5.0 (Android TV) UltraTVPro/11.0")
            }
            if (conn.responseCode !in 200..299) return null
            val baos = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            var total = 0
            conn.inputStream.use { stream ->
                while (true) {
                    if (Thread.currentThread().isInterrupted) return null
                    val read = stream.read(buf)
                    if (read == -1) break
                    total += read
                    if (total > MAX_IMAGE_BYTES) return null
                    baos.write(buf, 0, read)
                }
            }
            val bytes = baos.toByteArray()
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / sample > maxDim * 2 || bounds.outHeight / sample > maxDim * 2) {
                sample *= 2
            }
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        } catch (_: Throwable) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    fun trimMemory() {
        cache.evictAll()
    }

    private fun drawableToScaledBitmap(drawable: Drawable, targetH: Int): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            val src = drawable.bitmap
            if (src.width <= targetH * 2 && src.height <= targetH) return src
            val aspect = src.width.toFloat() / src.height.coerceAtLeast(1).toFloat()
            val outW = (targetH * aspect).toInt().coerceIn(targetH, targetH * 2)
            return Bitmap.createScaledBitmap(src, outW, targetH, true)
        }
        val w = drawable.intrinsicWidth.takeIf { it > 0 } ?: targetH
        val h = drawable.intrinsicHeight.takeIf { it > 0 } ?: targetH
        val aspect = w.toFloat() / h.coerceAtLeast(1).toFloat()
        val outW = (targetH * aspect).toInt().coerceIn(targetH, targetH * 2)
        val bitmap = Bitmap.createBitmap(outW, targetH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }
}
