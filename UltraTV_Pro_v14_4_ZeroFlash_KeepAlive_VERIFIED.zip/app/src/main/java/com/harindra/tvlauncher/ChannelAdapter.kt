package com.harindra.tvlauncher

import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class ChannelAdapter(
    private val prefs: PrefsManager,
    private val onChannelClick: (LiveChannel) -> Unit,
    private val onChannelLongClick: (LiveChannel) -> Unit
) : ListAdapter<LiveChannel, ChannelAdapter.ChannelViewHolder>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<LiveChannel>() {
            override fun areItemsTheSame(a: LiveChannel, b: LiveChannel) = a.streamUrl == b.streamUrl
            override fun areContentsTheSame(a: LiveChannel, b: LiveChannel) = a == b
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_channel_card, parent, false)
        return ChannelViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    override fun onViewRecycled(holder: ChannelViewHolder) {
        super.onViewRecycled(holder)
        MediaImageLoader.cancelRequest(holder.ivLogo)
    }

    inner class ChannelViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivLogo: ImageView = itemView.findViewById(R.id.ivChannelLogo)
        private val tvName: TextView = itemView.findViewById(R.id.tvChannelName)
        private val tvGroup: TextView = itemView.findViewById(R.id.tvChannelGroup)
        private val tvKey: TextView = itemView.findViewById(R.id.tvChannelKey)

        fun bind(ch: LiveChannel) {
            tvName.text = ch.name
            val isFav = ch.streamUrl in prefs.getFavoriteChannelIds()
            tvGroup.text = if (isFav) "★ ${ch.group}" else ch.group

            if (prefs.isUltraLiteMode) {
                ivLogo.setImageResource(R.drawable.ic_3d_livetv)
            } else {
                MediaImageLoader.loadRemoteImage(ch.logoUrl, ivLogo, R.drawable.ic_3d_livetv, 160)
            }

            val digit = prefs.findSpeedDialDigit("ch:${ch.streamUrl}")
            if (digit != null) { tvKey.visibility = View.VISIBLE; tvKey.text = "#$digit" }
            else tvKey.visibility = View.GONE

            itemView.setOnClickListener { onChannelClick(ch) }
            itemView.setOnLongClickListener { onChannelLongClick(ch); true }
            itemView.setOnKeyListener { _, keyCode, event ->
                if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_MENU) {
                    onChannelLongClick(ch); true
                } else false
            }
            itemView.setOnFocusChangeListener { v, hasFocus ->
                val tier = PerformanceTier.resolve(v.context, prefs)
                Animation4D.applyTierFocus(v, hasFocus, tier, prefs.enable4dAnimations)
            }
        }
    }
}
