package com.harindra.tvlauncher

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BootManager {

    const val MODE_HOME = 0
    const val MODE_AUTO_APP = 1
    const val MODE_LAST_CHANNEL = 2
    const val MODE_MOVIEBOX = 3

    fun executeBootStartup(context: Context, triggerAction: String) {
        val prefs = PrefsManager(context)
        KeepAliveService.start(context)
        BlackCurtainOverlay.show(context)
        val ts = SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault()).format(Date())

        // Mode 2: DTH Auto-Play Last Watched IPTV Channel (with safe recovery to Home)
        if (prefs.bootMode == MODE_LAST_CHANNEL && prefs.lastChannelUrl.isNotBlank()) {
            val streamIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(Uri.parse(prefs.lastChannelUrl), "video/*")
                putExtra("title", prefs.lastChannelName)
                if (prefs.preferredIptvPlayer.isNotBlank()) setPackage(prefs.preferredIptvPlayer)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(streamIntent)
                prefs.recordBootDiagnostic(ts, triggerAction, "OK: Resumed ${prefs.lastChannelName}")
                return
            } catch (e: Throwable) {
                prefs.recordBootDiagnostic(ts, triggerAction, "RECOVERED_TO_HOME (Channel failed: ${e.message})")
            }
        }

        // Mode 3: Auto-Launch MovieBox TV (with safe recovery to Home)
        if (prefs.bootMode == MODE_MOVIEBOX) {
            val launch = context.packageManager.getLeanbackLaunchIntentForPackage(MovieBoxEngine.MOVIEBOX_TV_PKG)
                ?: context.packageManager.getLaunchIntentForPackage(MovieBoxEngine.MOVIEBOX_TV_PKG)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    context.startActivity(launch)
                    prefs.recordBootDiagnostic(ts, triggerAction, "OK: Auto-launched MovieBox TV")
                    return
                } catch (e: Throwable) {
                    prefs.recordBootDiagnostic(ts, triggerAction, "RECOVERED_TO_HOME (MovieBox failed)")
                }
            }
        }

        // Mode 1: Auto-Launch Selected App (with safe recovery to Home)
        if (prefs.bootMode == MODE_AUTO_APP && prefs.autoLaunchPackage.isNotBlank()) {
            val pkg = prefs.autoLaunchPackage
            val launch = context.packageManager.getLeanbackLaunchIntentForPackage(pkg)
                ?: context.packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    context.startActivity(launch)
                    prefs.recordBootDiagnostic(ts, triggerAction, "OK: Auto-launched $pkg")
                    return
                } catch (e: Throwable) {
                    prefs.recordBootDiagnostic(ts, triggerAction, "RECOVERED_TO_HOME ($pkg failed)")
                }
            } else {
                prefs.recordBootDiagnostic(ts, triggerAction, "RECOVERED_TO_HOME ($pkg not installed)")
            }
        }

        // If UltraTV Pro is already the active default HOME and bootMode == MODE_HOME, Android launches us directly without duplicate chooser popup!
        if (prefs.bootMode == MODE_HOME && LauncherHomeManager.isDefaultHomeLauncher(context)) {
            prefs.recordBootDiagnostic(ts, triggerAction, "OK: System HOME active")
            return
        }

        // Default & Safe Recovery: Open UltraTV Pro Home Screen
        val homeIntent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        try {
            context.startActivity(homeIntent)
            if (prefs.bootMode == MODE_HOME) {
                prefs.recordBootDiagnostic(ts, triggerAction, "OK: Opened UltraTV Home")
            }
        } catch (e: Throwable) {
            prefs.recordBootDiagnostic(ts, triggerAction, "ERROR: ${e.message}")
        }
    }
}
