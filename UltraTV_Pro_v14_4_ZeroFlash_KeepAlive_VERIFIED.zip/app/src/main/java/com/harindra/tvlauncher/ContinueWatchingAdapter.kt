package com.harindra.tvlauncher

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.graphics.Outline
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class ContinueWatchingAdapter(
    private val prefs: PrefsManager,
    private val onItemClick: (ContinueWatchingItem) -> Unit,
    private val onItemFocused: ((String, Int) -> Unit)? = null
) : ListAdapter<ContinueWatchingItem, ContinueWatchingAdapter.CwViewHolder>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<ContinueWatchingItem>() {
            override fun areItemsTheSame(a: ContinueWatchingItem, b: ContinueWatchingItem) = a.id == b.id
            override fun areContentsTheSame(a: ContinueWatchingItem, b: ContinueWatchingItem) = a == b
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CwViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_continue_card, parent, false)
        return CwViewHolder(view)
    }

    override fun onBindViewHolder(holder: CwViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    override fun onViewRecycled(holder: CwViewHolder) {
        super.onViewRecycled(holder)
        MediaImageLoader.cancelRequest(holder.ivThumb)
    }

    inner class CwViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivThumb: ImageView = itemView.findViewById<ImageView>(R.id.ivCwThumb).apply {
            val r = 18f * resources.displayMetrics.density
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, r)
                }
            }
            clipToOutline = true
        }
        private val tvSource: TextView = itemView.findViewById(R.id.tvCwSourceBadge)
        private val tvTitle: TextView = itemView.findViewById(R.id.tvCwTitle)
        private val tvSub: TextView = itemView.findViewById(R.id.tvCwSubtitle)
        private val vProgress: View = itemView.findViewById(R.id.vCwProgress)

        fun bind(item: ContinueWatchingItem) {
            tvTitle.text = item.title
            tvSub.text = item.subtitle
            tvSource.text = item.sourceLabel

            val isYt = item.type == ContinueWatchingItem.TYPE_YOUTUBE || item.type == ContinueWatchingItem.TYPE_YOUTUBE_SEARCH
            val isMb = item.type == ContinueWatchingItem.TYPE_MOVIEBOX
            tvSource.setBackgroundResource(when { isMb -> R.drawable.bg_badge_moviebox; isYt -> R.drawable.bg_badge_yt; else -> R.drawable.bg_badge_iptv })
            vProgress.setBackgroundColor(when { isMb -> Color.parseColor("#F59E0B"); isYt -> Color.parseColor("#EF4444"); else -> Color.parseColor("#38BDF8") })

            val density = itemView.resources.displayMetrics.density
            val totalW = (304f * density).toInt()
            val lp = vProgress.layoutParams
            lp.width = (totalW * item.progressPercent.coerceIn(10, 98) / 100)
            vProgress.layoutParams = lp

            MediaImageLoader.loadRemoteImage(item.thumbUrl, ivThumb, item.fallbackResId, 440)

            itemView.setOnClickListener { onItemClick(item) }
            itemView.setOnFocusChangeListener { v, hasFocus ->
                val tier = PerformanceTier.resolve(v.context, prefs)
                Animation4D.applyTierFocus(v, hasFocus, tier, prefs.enable4dAnimations)
                if (hasFocus && tier.enableDynamicBackdrop) onItemFocused?.invoke(item.thumbUrl, item.fallbackResId)
            }
        }
    }
}
